# Lancer le proramme avec cette commade 
# Arguments pour la fonction fill array
# 3 -> taille du tableau
# 2 -> argument 1 du tableau
# 3 -> argument 2 du tableau
# 4 -> argument 3 du tableau

echo "3" "2" "3" "4" | ./exe


