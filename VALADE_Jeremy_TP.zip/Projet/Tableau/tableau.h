/* Fonction qui affiche un tableau */
void print_tableau(int tab[], int taille);
/* Calcule puis retourne la moyenne d'un tableau */
int moyenne(int tab[], int taille);
/* Trouve et retourne le minimum d'un tableau */
int min(int tab[], int taille);
/* Trouve et retourne le maximum d'un tableau */
int max(int tab[], int taille);
