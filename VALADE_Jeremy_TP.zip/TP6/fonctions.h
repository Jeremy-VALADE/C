int fread_board(const char* file, Board board);

/* Fonction qui résout un sudoku à une solution */
int solveSudoku(Board b, int row, int col);
