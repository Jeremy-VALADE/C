#include <stdio.h>

/*Programme qui affiche "HelloWorld" */
int main(){
	printf("Hello world\n");
	return 0;
}
