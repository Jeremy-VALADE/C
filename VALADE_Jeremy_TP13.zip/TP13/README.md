Pour exécuter le programme 

1 - Tapez make
2 - Exécuter la commande ./dame
3 - Jouer au jeu

Pour supprimer les fichiers .o et l'exécutable
Exécuter la commande make clean