Guide d'exécution de la calculatrice

Tapez la commande make
Lancer le programme avec la commande ./calc

Puis utiliser la calculatrice

Pour nettoyer les fichiers .o et le fichier d'exécution .calc,
tapez la commande make clean.

