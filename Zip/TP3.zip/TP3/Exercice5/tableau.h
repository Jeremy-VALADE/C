/* Fonction qui créait des tableaux aléatoire */
int* creationTableauAleatoire(int taille);

/* Fonction qui effectue le tri à bulle */
void tri_a_bulle(int tableau[], int taille);

/* Fonction qui affiche un tableau */ 
void afficherTableau(int tableau[], int taille);
